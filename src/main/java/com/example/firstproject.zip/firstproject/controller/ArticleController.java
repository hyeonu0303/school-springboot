package com.example.firstproject.controller;

import com.example.firstproject.dto.ArticleForm;
import com.example.firstproject.entity.Article;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import com.example.firstproject.repository.ArticleRepository;

@Controller
public class ArticleController {
    @Autowired
    ArticleRepository articleRepository;
    @GetMapping("/articles/new")
    public String newArticleForm(){
        return "articles/new";
    }

    @PostMapping("/articles/create")
    public String newArticleForm2(ArticleForm form){
        System.out.println(form.toString());
        Article saved = form.toEntity();
        Article savePrint = articleRepository.save(saved);
        System.out.println(savePrint.toString());
        return "redirect:/articles/" + saved.getId();
    }

    @GetMapping("/articles/{id}")
    public String show(@PathVariable("id") Long id){ //PathVarialbe : URL 경로에 변수를 넣어주는 것
        System.out.println("id : "+id);
        return"";
    }
}
